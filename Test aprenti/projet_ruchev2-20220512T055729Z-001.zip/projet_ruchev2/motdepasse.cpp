#include "motdepasse.h"
#include "mainwindow.h"
#include <QGroupBox>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QDebug>
#include <QCheckBox>
#include <QMessageBox>




motdepasse::motdepasse(QWidget *parent)
    : QWidget(parent)

{


    QGroupBox *echoGroupBox = new QGroupBox(tr("Conxeion"));
    QLabel *echoLable1 = new QLabel(tr("Identifiant :"));
    QLabel *echoLable2 = new QLabel(tr("mot de passe :"));


    QPushButton *b0 = new QPushButton(tr("0"));
    QPushButton *b1 = new QPushButton(tr("1"));
    QPushButton *b2 = new QPushButton(tr("2"));
    QPushButton *b3 = new QPushButton(tr("3"));
    QPushButton *b4 = new QPushButton(tr("4"));
    QPushButton *b5 = new QPushButton(tr("5"));
    QPushButton *b6 = new QPushButton(tr("6"));
    QPushButton *b7 = new QPushButton(tr("7"));
    QPushButton *b8 = new QPushButton(tr("8"));
    QPushButton *b9 = new QPushButton(tr("9"));
    QPushButton *connection = new QPushButton(tr("Conexion"));

     checkid = new QCheckBox(this);
     checkmdp = new QCheckBox(this);
     result = new QLabel(this);


    QGridLayout *echolayout = new QGridLayout;

    identif = new QLineEdit;
    mdp = new QLineEdit;
    identif->setPlaceholderText("entre votre identifiant");
    identif->setMaxLength(6);
    mdp->setPlaceholderText("entre votre mot de passe");





    echoGroupBox->setLayout(echolayout);
    echolayout->addWidget(echoLable1, 0,0);
    echolayout->addWidget(echoLable2, 1,0);
    echolayout->addWidget(identif,0,1,1,1);
    echolayout->addWidget(mdp,1,1,1,1);
    echolayout->addWidget(checkid,0,2);
    echolayout->addWidget(checkmdp,1,2);



    echolayout->addWidget(b1,2,0);
    echolayout->addWidget(b2,2,1);
    echolayout->addWidget(b3,2,2);
    echolayout->addWidget(b4,3,0);
    echolayout->addWidget(b5,3,1);
    echolayout->addWidget(b6,3,2);
    echolayout->addWidget(b7,4,0);
    echolayout->addWidget(b8,4,1);
    echolayout->addWidget(b9,4,2);
    echolayout->addWidget(b0,5,1);
    echolayout->addWidget(connection, 6,1);
    echolayout->addWidget(result,7,1);


    QGridLayout *layout = new QGridLayout;

    layout->addWidget(echoGroupBox,0,0);
    setLayout(layout);

    setWindowTitle(tr("Conexion"));


     mdp->setEchoMode(QLineEdit::Password);

   // connect(checkid,(&QCheckBox::stateChanged), this, &motdepasse::check );
/*
    if (checkid->checkState()!= 2)
    {
       identif->setEchoMode(QLineEdit::Normal);
    }
    else
    {
        identif->setEchoMode(QLineEdit::Password);
    }
*/





      connect(checkid, SIGNAL(clicked()),this,SLOT(check()));
      connect(checkmdp, SIGNAL(clicked()),this,SLOT(check2()));
      connect(connection, SIGNAL(clicked()), this, SLOT(conexion()));

      connect(b1, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b2, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b3, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b4, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b5, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b6, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b7, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b8, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b9, SIGNAL(clicked()),this,SLOT(ecriture2()));
      connect(b0, SIGNAL(clicked()),this,SLOT(ecriture2()));



}

void motdepasse::check()
{

    if(checkid->isChecked())
    {
    identif->setEchoMode(QLineEdit::Normal);
}
    else {
        identif->setEchoMode(QLineEdit::Password);
    }
}

void motdepasse::check2()
{

    if(checkmdp->isChecked())
    {
    mdp->setEchoMode(QLineEdit::Normal);
}
    else {
        mdp->setEchoMode(QLineEdit::Password);
    }
}



void motdepasse::ecriture2()
{
    QPushButton *but = (QPushButton *)sender();

    id = (identif->text()+but->text());

    identif->setText(id);

    if(identif->isEnabled())
    {
    if (id.size() == 6)
    {
        identif->setText(id);
        identif->setDisabled(1);

    }
    }
    else if(!identif->isEnabled())
    {
        md = (mdp->text()+but->text());
        mdp->setText(md);

    }
}


void motdepasse::conexion()
{


    QString motverif = "123456";
    QString identifverif = "01102002";


    qDebug()<<mdp->text()<<""<<identif->text();


    if(identif->text() == motverif && mdp->text() == identifverif)
      {
        result->setText("Conexion verifier");
       connection->setStyleSheet("background-color: #25E222;");

       MainWindow *a = new MainWindow;
       a->show();
        close();


          }
        else
    {
         //result->setText("Conexion non verifier");
         connection->setStyleSheet("background-color: #E22222;");
         erreur += 1;
         if(identif->text() != motverif)
         {
             QMessageBox::information(this,"titre", "Votre identifiant n'est pas bon");
             identif->setEnabled(1);

         }
         result->setText("Code Erroné (encore "+QString::number(3 - erreur)+" essais)");
         if(erreur == 3)
         {
             close();
         }

    }
}












