#ifndef MOTDEPASSE_H
#define MOTDEPASSE_H

#include <QWidget>
#include <QCheckBox>
#include <QPushButton>
#include <QLabel>

QT_BEGIN_NAMESPACE
class QLineEdit;
QT_END_NAMESPACE

class motdepasse : public QWidget
{
    Q_OBJECT

public:
    motdepasse(QWidget *parent = nullptr);
    QString md;
    QString id;
    int num;
    int taille1, taille2;




public slots:
    void check();
    void check2();
    void ecriture2();
    void conexion();




    //void checkinv();
private:
    int erreur;
    QLineEdit *identif;
    QLineEdit *mdp;
    QCheckBox *checkid ;
    QCheckBox *checkmdp ;
    QLabel *result;
    QPushButton *b0 = new QPushButton(tr("0"));
    QPushButton *b1 = new QPushButton(tr("1"));
    QPushButton *b2 = new QPushButton(tr("2"));
    QPushButton *b3 = new QPushButton(tr("3"));
    QPushButton *b4 = new QPushButton(tr("4"));
    QPushButton *b5 = new QPushButton(tr("5"));
    QPushButton *b6 = new QPushButton(tr("6"));
    QPushButton *b7 = new QPushButton(tr("7"));
    QPushButton *b8 = new QPushButton(tr("8"));
    QPushButton *b9 = new QPushButton(tr("9"));
    QPushButton *connection = new QPushButton(tr("Conexion"));
    QPushButton *b =new QPushButton();


};
#endif // MOTDEPASSE_H
