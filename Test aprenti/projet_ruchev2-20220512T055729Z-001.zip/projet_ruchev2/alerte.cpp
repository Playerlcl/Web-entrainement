#include "alerte.h"
#include <QFile>
#include <QMessageBox>
#include <QDebug>


alert::alert(QWidget *parent):
QWidget(parent)
{


}

void alert::comparer()
{
    QFile fichier("/Users/Shared/projet_ruchev2/tempa.txt");
    fichier.open(QIODevice::ReadOnly);
    QString contenuun = fichier.readAll();
    fichier.close();

    QFile fichieruniter("/Users/Shared/projet_ruchev2/tempa.txt");
    fichier.open(QIODevice::ReadOnly);
   QString contenuse = fichier.readAll();
    fichier.close();


    contenuseuil = contenuse.toInt();
    contenuuniter = contenuun.toInt();
    qDebug()<<contenuseuil;
    qDebug()<<contenuuniter;


    if (contenuseuil < contenuuniter )
    {

        QMessageBox::information(this, "alerte valeur", "le seuil de temperature a etait depaser");
    }





}
