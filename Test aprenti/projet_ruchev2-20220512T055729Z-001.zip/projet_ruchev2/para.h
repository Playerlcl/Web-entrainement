#ifndef PARA_H
#define PARA_H
#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QLabel>
#include <QGridLayout>
#include <QGroupBox>
#include <QCheckBox>
#include <QComboBox>


namespace Ui{
class para;
}
class para : public QWidget
 {
    Q_OBJECT

public:
    explicit para(QWidget *parent = nullptr);
    QLabel *temperature = new QLabel;
    QString contenut;
    QString contenuh;
    QString contenupo;
    QString contenupl;
    QPushButton *actualiser = new QPushButton;
    QLabel *temperatur = new QLabel;
    QLabel *humiditer = new QLabel;
    QLabel *poid = new QLabel;
    QLabel *pluie = new QLabel;
    QLabel *humidite = new QLabel;
    QLabel *poi = new QLabel;
    QLabel *plui = new QLabel;
    QLabel *degres = new QLabel;
    QLabel *seuilhumi = new QLabel;
    QLabel *seuilpoid = new QLabel;
    QLabel *seuilne= new QLabel;


    QGridLayout *echolayout = new QGridLayout;
    QGroupBox *echogroup = new QGroupBox;
    QGridLayout *Finallayout = new QGridLayout;

    QCheckBox *seuiltem= new QCheckBox;
    QLineEdit *changement = new QLineEdit;

    QCheckBox *seuilhum= new QCheckBox;
    QLineEdit *changementh = new QLineEdit;

    QCheckBox *seuilp= new QCheckBox;
    QLineEdit *changementp = new QLineEdit;

    QCheckBox *seuiln= new QCheckBox;
    QLineEdit *changementn = new QLineEdit;

    QPushButton *boutonvt = new QPushButton;
    QPushButton *boutonvp = new QPushButton;
    QPushButton *boutonvn = new QPushButton;
    QPushButton *boutonvh = new QPushButton;


    QPushButton *Quit = new QPushButton;



public slots:
       void actu();
       void seuilt();
       void seuilh();
       void seuilpoi();
       void seuilniv();

       void modiftemp();
       void modifhumiditer();
       void modifpoid();
       void modifniv();


private:

};


#endif // PARA_H
