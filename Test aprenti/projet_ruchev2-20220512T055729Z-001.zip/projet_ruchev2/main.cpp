#include "mainwindow.h"
#include "para.h"
#include "motdepasse.h"
#include <QApplication>
#include <QFile>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QFile StyleSheetFile("/Users/mac/Desktop/qss/Combinear.qss");
    StyleSheetFile.open(QFile::ReadOnly);
    QString StyleSheet = QLatin1String(StyleSheetFile.readAll());
    a.setStyleSheet(StyleSheet);
    motdepasse w;
    MainWindow s;
    //para fenetre;
   // fenetre.show();
    s.show();

    return a.exec();
}
