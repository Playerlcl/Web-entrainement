#include "consulter.h"
#include <QGridLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QFile>

consult::consult(QWidget *parent):
QWidget(parent)
{


    setMinimumSize(200,200);
    setMaximumSize(400,300);
    setWindowTitle("Consulter les valeur");

//Declaration de tout la parti interface (bouton , layout ect...)

    QGridLayout *echogrid = new QGridLayout;
    QGroupBox *echogroup = new QGroupBox;
    QGridLayout *final = new QGridLayout;



    echogroup->setLayout(echogrid);

    actualiser->setText("actualiser");
    temperatur->setText("La temperatur est :");
    humiditer->setText("l' 'humiditer est :");
    poid->setText("le poid est :");
    pluie->setText("le % de pluie est :");



//placement de tout les widgets dans le layout principal
    echogroup->setLayout(echogrid);
    echogrid->addWidget(actualiser, 0,3);
    echogrid->addWidget(temperatur,1,0);
    echogrid->addWidget(humiditer,2,0 );
    echogrid->addWidget(poid,3,0);
    echogrid->addWidget(pluie,4,0);

    echogrid->addWidget(temperature, 1,1);
    echogrid->addWidget(humidite, 2,1);
    echogrid->addWidget(poi, 3,1);
    echogrid->addWidget(plui, 4,1);
    final->addWidget(echogroup);
    setLayout(final);


//ouverture des fichiers afin d afficher au demarage les valeurs enregistrer
    QFile fichiert("/Users/Shared/projet_ruchev2/tempa.txt");
    QFile fichierh("/Users/Shared/projet_ruchev2/humiditera.txt");
    QFile fichierpl("/Users/Shared/projet_ruchev2/pluiea.txt");
    QFile fichierpo("/Users/Shared/projet_ruchev2/poida.txt");
    fichiert.open(QIODevice::ReadOnly);
    contenut = fichiert.readAll();
    temperature->setText(contenut);
    fichiert.close();

    fichierh.open(QIODevice::ReadOnly);
    contenuh = fichierh.readAll();
    humidite->setText(contenuh);
    fichierh.close();

    fichierpl.open(QIODevice::ReadOnly);
    contenupl = fichierpl.readAll();
    plui->setText(contenupl);
    fichierpl.close();

    fichierpo.open(QIODevice::ReadOnly);
    contenupo = fichierpo.readAll();
    poi->setText(contenupo);
    fichierpo.close();

//Assigner le bouton actualiser a la fonction lié
   connect(actualiser,SIGNAL(clicked()), this, SLOT(actualise()));
}
//fonction actualiser
void consult::actualise()
{
    QFile fichiert("/Users/Shared/projet_ruchev2/tempa.txt");
    QFile fichierh("/Users/Shared/projet_ruchev2/humiditera.txt");
    QFile fichierpl("/Users/Shared/projet_ruchev2/pluiea.txt");
    QFile fichierpo("/Users/Shared/projet_ruchev2/poida.txt");
    fichiert.open(QIODevice::ReadOnly);
    contenut = fichiert.readAll();
    temperature->setText(contenut);
    fichiert.close();

    fichierh.open(QIODevice::ReadOnly);
    contenuh = fichierh.readAll();
    humidite->setText(contenuh);
    fichierh.close();

    fichierpl.open(QIODevice::ReadOnly);
    contenupl = fichierpl.readAll();
    plui->setText(contenupl);
    fichierpl.close();

    fichierpo.open(QIODevice::ReadOnly);
    contenupo = fichierpo.readAll();
    poi->setText(contenupo);
    fichierpo.close();


    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("127.0.0.1");
    db.setUserName("root@localhost");
    db.setPassword("07paris11A");
    db.setDatabaseName("ruche");


    if (db.open())
    {
        QMessageBox::information(this, "conection bdd", "bdd est conecter");
    }else
        {
    QMessageBox::information(this, "conection bdd", "bdd pas connecter");
    }


}
