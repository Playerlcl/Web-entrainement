#ifndef CONSULTER_H
#define CONSULTER_H

#include <QWidget>
#include <QPushButton>
#include <QLayout>
#include <QLabel>
#include <QSqlDatabase>
#include <QSql>

class consult : public QWidget
{
    Q_OBJECT

public :
        consult(QWidget *parent = nullptr);
        QLabel *temperature = new QLabel;
        QString contenut;
        QString contenuh;
        QString contenupo;
        QString contenupl;
        QPushButton *actualiser = new QPushButton;
        QLabel *temperatur = new QLabel;
        QLabel *humiditer = new QLabel;
        QLabel *poid = new QLabel;
        QLabel *pluie = new QLabel;
        QLabel *humidite = new QLabel;
        QLabel *poi = new QLabel;
        QLabel *plui = new QLabel;
public slots:
        void actualise();



};





#endif // CONSULTER_H
