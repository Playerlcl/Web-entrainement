#ifndef ALERTE_H
#define ALERTE_H
#include <QWidget>

class alert : public QWidget
{
    Q_OBJECT

public:
    alert(QWidget *parent = nullptr);

public slots:
    void comparer();



private:
    QString valseuil;
    QString valuniter;
    int contenuseuil;
    int contenuuniter;


};

#endif // ALERTE_H
