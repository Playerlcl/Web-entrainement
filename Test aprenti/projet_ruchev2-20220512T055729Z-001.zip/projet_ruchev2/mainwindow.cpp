 #include "mainwindow.h"
#include "ui_mainwindow.h"
#include "consulter.h"
#include "para.h"
#include <QWidget>
#include <QFile>
#include <QMessageBox>
#include <QDebug>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    //decalration de la fenetre principal ou sera mit nos onglet
    ui->setupUi(this);
    setMinimumSize(600,400);
    setWindowTitle("CorBuzz");

    //creation du widget pour l'onglet
    onglet->setMovable(true);
    onglet->setTabPosition(QTabWidget::North);

    //place l'onglet parametre et consulter
    para *parametr = new para;
    onglet->addTab(parametr, "Parametre seuil");

    consult *consulter = new consult;
    onglet->addTab(consulter,"Consulter");

    setCentralWidget(onglet);

}

//permet de gérer les alertes
void MainWindow::comparer()
{
    QFile fichier("/Users/Shared/projet_ruchev2/tempa.txt");
    fichier.open(QIODevice::ReadOnly);
    QString contenuun = fichier.readAll();
    fichier.close();

    QFile fichieruniter("/Users/Shared/projet_ruchev2/temp.txt");
    fichieruniter.open(QIODevice::ReadOnly);
   QString contenuse = fichieruniter.read(16);
    fichieruniter.close();

    QFile fichierh("/Users/Shared/projet_ruchev2/humiditera.txt");
    fichierh.open(QIODevice::ReadOnly);
    QString contenuhu = fichierh.readAll();
    fichierh.close();

    QFile fichierhu("/Users/Shared/projet_ruchev2/humiditer.txt");
    fichierhu.open(QIODevice::ReadOnly);
   QString contenusehu = fichierhu.read(16);
    fichierhu.close();

    QFile fichierp("/Users/Shared/projet_ruchev2/poida.txt");
    fichierp.open(QIODevice::ReadOnly);
    QString contenup = fichierp.readAll();
    fichierp.close();

    QFile fichierpo("/Users/Shared/projet_ruchev2/poid.txt");
    fichierpo.open(QIODevice::ReadOnly);
   QString contenusepo = fichierpo.read(16);
    fichierpo.close();

    QFile fichiern("/Users/Shared/projet_ruchev2/pluiea.txt");
    fichiern.open(QIODevice::ReadOnly);
    QString contenun = fichiern.readAll();
    fichiern.close();

    QFile fichierne("/Users/Shared/projet_ruchev2/pluie.txt");
    fichierne.open(QIODevice::ReadOnly);
   QString contenusene = fichierne.read(16);
    fichierne.close();





    contenuseuil = contenuse.toInt();
    contenuuniter = contenuun.toInt();

    contenuseuilh = contenusehu.toInt();
    contenuuniterh = contenuhu.toInt();

    contenuseuilp = contenusepo.toInt();
    contenuuniterp = contenup.toInt();

    contenuseuiln = contenusene.toInt();
    contenuunitern = contenun.toInt();







    qDebug()<<"temp"<<contenuseuil;
    qDebug()<<contenuuniter;

    qDebug()<<"humi"<<contenuseuilh;
    qDebug()<<contenuuniterh;

    qDebug()<<"poid"<<contenuseuilp;
    qDebug()<<contenuuniterp;


    qDebug()<<"niveau d eau"<<contenuseuiln;
    qDebug()<<contenuunitern;



    if (contenuseuil < contenuuniter )
    {

        QMessageBox::information(this, "alerte valeur", "le seuil de temperature a etait depaser");
    }

    if (contenuseuilh < contenuuniterh )
    {

        QMessageBox::information(this, "alerte valeur", "le seuil d'humiditer a etait depaser");
    }

    if (contenuseuilp < contenuuniterp )
    {

        QMessageBox::information(this, "alerte valeur", "le seuil de poid a etait depaser");
    }




}

MainWindow::~MainWindow()
{
    delete ui;
}
