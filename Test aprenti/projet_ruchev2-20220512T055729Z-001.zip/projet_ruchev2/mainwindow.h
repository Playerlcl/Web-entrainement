#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QRadioButton>
#include <QSql>
#include <QSqlDatabase>
#include <QTabWidget>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public :
    MainWindow(QWidget *parent = nullptr);
    QTabWidget *onglet = new QTabWidget;
~MainWindow();



public slots:


    void comparer();
    //void afficherhistorique();


private:
    Ui::MainWindow *ui;
    QPushButton *parametre_but ;
    QPushButton *mesur_but;
    QPushButton *aide_but;
    QPushButton *quitter_but;
    QPushButton *affcher_but;
    QLabel *label;
    QLabel *label2;
    QRadioButton check_but;
    QString valseuil;
    QString valuniter;
    int contenuseuil;
    int contenuuniter;

    int contenuseuilh;
    int contenuuniterh;

    int contenuseuilp;
    int contenuuniterp;

    int contenuseuiln;
    int contenuunitern;
};

#endif // MAINWINDOW_H
