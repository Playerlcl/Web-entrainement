#ifndef PARAMETRE_H
#define PARAMETRE_H


class parametre
{

public slot:
    parametre();


};

#endif // PARAMETRE_H
