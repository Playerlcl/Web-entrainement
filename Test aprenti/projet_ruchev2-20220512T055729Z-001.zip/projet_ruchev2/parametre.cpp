#include "para.h"
#include "mainwindow.h"
#include <QWidget>
#include <QGroupBox>
#include <QGridLayout>
#include <QMessageBox>
#include <QPushButton>
#include <QFile>
#include <QComboBox>
#include <QCheckBox>
#include <QDebug>
#include <QCheckBox>


para::para(QWidget *parent) :
    QWidget(parent)

{
    //definition de la fenetre
    setMinimumSize(200,200);
    setWindowTitle(("Parametrer le seuil"));
    
    //definition et configuration des widget
    seuiltem->setText("modifier le seuil de temp");
    seuilhum->setText("modifier le seuil d humiditer");
    seuilp->setText("modifier le seuil de poid");
    seuiln->setText("modifier le seuil de niveau d eau");

    actualiser->setText("actualiser");
    temperatur->setText("le seuil actuel de temperatur est :");
    humiditer->setText("le seuil actuel de l humiditer est :");
    poid->setText("le seuil actuel de poid est :");
    pluie->setText("le seuil acutel de niveau d'eau est :");


    //mise en place des widget sur le layout
    echogroup->setLayout(echolayout);
    echolayout->addWidget(actualiser, 0,3);
    echolayout->addWidget(temperatur,1,0);
    echolayout->addWidget(humiditer,2,0 );
    echolayout->addWidget(poid,3,0);
    echolayout->addWidget(pluie,4,0);

    echolayout->addWidget(temperature, 1,1);
    echolayout->addWidget(humidite, 2,1);
    echolayout->addWidget(poi, 3,1);
    echolayout->addWidget(plui, 4,1);

    echolayout->addWidget(seuiltem,7,0);
    echolayout->addWidget(seuilhum,8, 0);
    echolayout->addWidget(seuilp,9,0);
    echolayout->addWidget(seuiln,10,0);
    echolayout->addWidget(Quit,11,3);

    Finallayout->addWidget(echogroup);
    setLayout(Finallayout);




//ouverture des fichier afin d avoir accées au seuil enregistrer
    QFile fichiert("/Users/Shared/projet_ruchev2/temp.txt");
    QFile fichierh("/Users/Shared/projet_ruchev2/humiditer.txt");
    QFile fichierpl("/Users/Shared/projet_ruchev2/pluie.txt");
    QFile fichierpo("/Users/Shared/projet_ruchev2/poid.txt");
    fichiert.open(QIODevice::ReadOnly);
    contenut = fichiert.readAll();
    temperature->setText(contenut);
    fichiert.close();

    fichierh.open(QIODevice::ReadOnly);
    contenuh = fichierh.readAll();
    humidite->setText(contenuh);
    fichierh.close();

    fichierpl.open(QIODevice::ReadOnly);
    contenupl = fichierpl.readAll();
    plui->setText(contenupl);
    fichierpl.close();

    fichierpo.open(QIODevice::ReadOnly);
    contenupo = fichierpo.readAll();
    poi->setText(contenupo);
    fichierpo.close();


    //configuration des boutons pour modifier les seuils

     boutonvh->setText("swap");
     boutonvt->setText("swap");
     boutonvp->setText("swap");
     boutonvn->setText("swap");

     boutonvh->setMaximumSize(75, 25);
     boutonvt->setMaximumSize(75, 25);
     boutonvp->setMaximumSize(75,25);




connect(seuiltem,SIGNAL(clicked()),this,SLOT(seuilt()));
connect(seuilhum, SIGNAL(clicked()),this, SLOT(seuilh()));
connect(seuilp,SIGNAL(clicked()),this,SLOT(seuilpoi()));
connect(seuiln,SIGNAL(clicked()),this,SLOT(seuilniv()));

connect(boutonvt,SIGNAL(clicked()),this,SLOT(modiftemp()));
connect(boutonvh,SIGNAL(clicked()),this,SLOT(modifhumiditer()));
connect(boutonvp,SIGNAL(clicked()),this,SLOT(modifpoid()));
connect(boutonvn,SIGNAL(clicked()),this,SLOT(modifniv()));

connect(actualiser,SIGNAL(clicked()), this, SLOT(actu()));


}

//fonction actualiser les euil
void para::actu()
{
    QFile fichiert("/Users/Shared/projet_ruchev2/temp.txt");
    QFile fichierh("/Users/Shared/projet_ruchev2/humiditer.txt");
    QFile fichierpl("/Users/Shared/projet_ruchev2/pluie.txt");
    QFile fichierpo("/Users/Shared/projet_ruchev2/poid.txt");
    fichiert.open(QIODevice::ReadOnly);
    contenut = fichiert.readAll();
    temperature->setText(contenut);
    fichiert.close();

    fichierh.open(QIODevice::ReadOnly);
    contenuh = fichierh.readAll();
    humidite->setText(contenuh);
    fichierh.close();

    fichierpl.open(QIODevice::ReadOnly);
    contenupl = fichierpl.readAll();
    plui->setText(contenupl);
    fichierpl.close();

    fichierpo.open(QIODevice::ReadOnly);
    contenupo = fichierpo.readAll();
    poi->setText(contenupo);
    fichierpo.close();
}

//fonction lier au checkbox de temperature
void para::seuilt()
{
    changement->setMinimumSize(75,25);

    if(seuiltem->isChecked())
    {
    echolayout->addWidget(changement,7,2);
    echolayout->addWidget(boutonvt,7,3);
    qDebug()<<"check";
    changement->setVisible(true);
    boutonvt->setVisible(true);
    }
    else if (!(seuiltem->isChecked()))
    {
        //echolayout->removeWidget(changement);
        qDebug()<<"ncheck";
        changement->setVisible(false);// hide();
        boutonvt->setVisible(false);
    }
}
//fonction lier au checkbox de niv d'eau
void para::seuilniv()
{
    changementn->setMinimumSize(75,25);

    if(seuiln->isChecked())
    {
    echolayout->addWidget(changementn,10,2);
    echolayout->addWidget(boutonvn,10,3);
    qDebug()<<"check";
    changementn->setVisible(true);
    boutonvn->setVisible(true);
    }
    else if (!(seuiln->isChecked()))
    {
        //echolayout->removeWidget(changement);
        qDebug()<<"ncheck";
        changementn->setVisible(false);// hide();
        boutonvn->setVisible(false);
    }
}


//fonction lier au checkbox d'humiditer
void para::seuilh()
{
    changementh->setMinimumSize(75,25);
    if(seuilhum->isChecked())
    {
        echolayout->addWidget(changementh,8,2);
        echolayout->addWidget(boutonvh,8,3);
        boutonvh->setVisible(true);
        changementh->setVisible(true);
    }
    else  if(!(seuilhum->isChecked()))
    {
        boutonvh->setVisible(false);
        changementh->setVisible(false);
    }
}
//fonction lier au checkbox de poid
void para::seuilpoi()
{
    changementp->setMinimumSize(75,25);
    if(seuilp->isChecked())
    {
        echolayout->addWidget(changementp,9,2);
        echolayout->addWidget(boutonvp,9,3);
        boutonvp->setVisible(true);
        changementp->setVisible(true);
    }
    else  if(!(seuilp->isChecked()))
    {
        boutonvp->setVisible(false);
        changementp->setVisible(false);
    }
}

//fonction pour modifier la valeur du seuil dans le fichier
void para::modiftemp()
{
    QFile fichier("/Users/Shared/projet_ruchev2/temp.txt");
    fichier.open(QIODevice::ReadOnly);
    contenupo = fichier.readAll();
    fichier.close();

    fichier.open(QIODevice::WriteOnly);
    QTextStream out(&fichier);
    contenut = changement->text();
    out <<contenut;
    qDebug()<<contenut;
    fichier.close();

    qDebug()<<"cliquer";
}


void para::modifhumiditer()
{
    QFile fichier("/Users/Shared/projet_ruchev2/humiditer.txt");
    fichier.open(QIODevice::ReadOnly);
    contenupo = fichier.readAll();
    fichier.close();

    fichier.open(QIODevice::WriteOnly);
    QTextStream out(&fichier);
    contenuh = changementh->text();
    out <<contenuh;
    qDebug()<<contenuh;
    fichier.close();

    qDebug()<<"cliquerH";
}

void para::modifpoid()
{
    QFile fichier("/Users/Shared/projet_ruchev2/poid.txt");
    fichier.open(QIODevice::ReadOnly);
    contenupo = fichier.readAll();
    fichier.close();

    fichier.open(QIODevice::WriteOnly);
    QTextStream out(&fichier);
    contenupo = changementp->text();
    out <<contenupo;
    qDebug()<<contenupo;
    fichier.close();

    qDebug()<<"cliquerH";
}
void para::modifniv()
{
    QFile fichier("/Users/Shared/projet_ruchev2/pluie.txt");
    fichier.open(QIODevice::ReadOnly);
    contenupo = fichier.readAll();
    fichier.close();

    fichier.open(QIODevice::WriteOnly);
    QTextStream out(&fichier);
    contenupl = changementn->text();
    out <<contenupl;
    qDebug()<<contenupo;
    fichier.close();

    qDebug()<<"cliquerH";
}

